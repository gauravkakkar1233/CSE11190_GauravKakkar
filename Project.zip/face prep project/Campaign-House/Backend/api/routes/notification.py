from fastapi import APIRouter, Depends, HTTPException

from models.notification import Notification
from models.user import User
from schemas.notification import NotificationRead
from schemas.common import Response
from api.deps import get_current_user

router = APIRouter()


@router.get("", response_model=Response[list[dict]])
async def list_notifications(
    user: User = Depends(get_current_user),
):
    items = await Notification.find(
        Notification.user_id == user.id
    ).sort([("created_at", -1)]).to_list()
    
    result = []
    for c in items:
        d = c.model_dump(exclude={"revision_id"})
        d["id"] = c.id
        result.append(d)
        
    return {"data": result}


@router.patch("/{notification_id}/read", response_model=Response[dict])
async def mark_notification_read(
    notification_id: int,
    user: User = Depends(get_current_user),
):
    notif = await Notification.find_one(Notification.id == notification_id)

    if not notif:
        raise HTTPException(status_code=404, detail="Notification not found")

    if notif.user_id != user.id:
        raise HTTPException(status_code=403, detail="Not authorized")

    notif.is_read = True
    await notif.save()

    d = notif.model_dump(exclude={"revision_id"})
    d["id"] = notif.id
    return {"data": d}


@router.post("/read-all")
async def mark_all_read(
    user: User = Depends(get_current_user),
):
    items = await Notification.find(
        Notification.user_id == user.id,
        Notification.is_read == False  # noqa: E712
    ).to_list()

    for n in items:
        n.is_read = True
        await n.save()

    return {"updated": len(items)}
