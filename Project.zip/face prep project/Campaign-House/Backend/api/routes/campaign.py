from datetime import datetime
from fastapi import APIRouter, Depends, Query, Request, HTTPException

from models.campaign import Campaign
from models.user import User
from schemas.campaign import CampaignCreate, CampaignUpdate
from schemas.common import Response, PaginatedResponse
from utils.pagination import encode_cursor, decode_cursor
from api.deps import get_current_user
from models.history import History
from models.notification import Notification

router = APIRouter()


@router.get("/stats")
async def get_campaign_stats(
    user: User = Depends(get_current_user)
):
    campaigns = await Campaign.find_all().to_list()

    now = datetime.now()
    total = len(campaigns)

    completed = len([c for c in campaigns if c.due_date and c.due_date < now])
    active = total - completed

    return {
        "total": total,
        "active": active,
        "completed": completed
    }


@router.get("", response_model=PaginatedResponse[list[dict]])
async def read_campaigns(
    request: Request,
    cursor: str | None = Query(None),
    limit: int = 20,
    q: str | None = Query(None, description="Search by name or description (partial, case-insensitive)"),
    category_id: int | None = Query(None, description="Filter by category id"),
    state: str | None = Query(None, description="Filter by state (partial, case-insensitive)"),
    city: str | None = Query(None, description="Filter by city (partial, case-insensitive)"),
    due_by: datetime | None = Query(None, description="Only campaigns due on or before this datetime"),
    status: str | None = Query(None, description="Filter by computed status: 'active' or 'completed'"),
    sort: str | None = Query(
        None,
        description="Sort order: 'oldest' (default) | 'latest' | 'due_date' | 'name'",
    ),
    user: User = Depends(get_current_user)
):
    cursor_id = decode_cursor(cursor) if cursor else 0
    now = datetime.now()

    sort_key = (sort or "oldest").lower().strip()

    # Build MongoDB filter
    filters = {}

    if sort_key == "oldest" and cursor_id:
        filters["campaign_id"] = {"$gt": cursor_id}

    if q:
        import re
        pattern = re.escape(q.strip())
        filters["$or"] = [
            {"name": {"$regex": pattern, "$options": "i"}},
            {"description": {"$regex": pattern, "$options": "i"}},
        ]

    if category_id is not None:
        filters["category_id"] = category_id
    if state:
        filters["state"] = {"$regex": re.escape(state.strip()) if 'pattern' not in dir() else state.strip(), "$options": "i"}
    if city:
        filters["city"] = {"$regex": city.strip(), "$options": "i"}
    if due_by is not None:
        filters["due_date"] = {"$ne": None, "$lte": due_by}

    if status:
        s = status.lower().strip()
        if s == "active":
            filters["$or"] = [
                {"due_date": None},
                {"due_date": {"$gt": now}},
            ]
        elif s == "completed":
            filters.setdefault("due_date", {})
            if isinstance(filters["due_date"], dict):
                filters["due_date"]["$ne"] = None
                filters["due_date"]["$lte"] = now
            else:
                filters["due_date"] = {"$ne": None, "$lte": now}

    # Build sort
    if sort_key == "latest":
        sort_spec = [("campaign_id", -1)]
    elif sort_key == "due_date":
        sort_spec = [("due_date", 1), ("campaign_id", 1)]
    elif sort_key == "name":
        sort_spec = [("name", 1), ("campaign_id", 1)]
    else:  # oldest
        sort_spec = [("campaign_id", 1)]

    data = await Campaign.find(filters).sort(sort_spec).limit(limit + 1).to_list()

    # Compute status based on due_date
    for c in data:
        if c.due_date and c.due_date < now:
            c.status = "completed"
        else:
            c.status = "active"

    base_url = str(request.url).split("?")[0]
    next_url = None

    if sort_key == "oldest" and len(data) > limit:
        from urllib.parse import quote_plus
        next_cursor = encode_cursor(data[:limit][-1].campaign_id)
        parts = [f"cursor={next_cursor}", f"limit={limit}"]
        if q:
            parts.append(f"q={quote_plus(q)}")
        if category_id is not None:
            parts.append(f"category_id={category_id}")
        if state:
            parts.append(f"state={quote_plus(state)}")
        if city:
            parts.append(f"city={quote_plus(city)}")
        if due_by is not None:
            parts.append(f"due_by={quote_plus(due_by.isoformat())}")
        if status:
            parts.append(f"status={quote_plus(status)}")
        next_url = f"{base_url}?{'&'.join(parts)}"

    # Serialize campaigns to dicts (excluding MongoDB _id)
    result_data = []
    for c in data[:limit]:
        d = c.model_dump(exclude={"id", "revision_id"})
        result_data.append(d)

    return {
        "data": result_data,
        "next": next_url
    }


@router.get("/{id}", response_model=Response[dict])
async def get_campaign(
    id: int,
    user: User = Depends(get_current_user)
):
    data = await Campaign.find_one(Campaign.campaign_id == id)

    if not data:
        raise HTTPException(status_code=404, detail="Campaign not found")

    result = data.model_dump(exclude={"id", "revision_id"})
    return {"data": result}


@router.post("", status_code=201, response_model=Response[dict])
async def create_campaign(
    campaign: CampaignCreate,
    user: User = Depends(get_current_user)
):
    if user.role != "admin":
        raise HTTPException(
            status_code=403,
            detail="Only admins can create campaigns",
        )

    db = Campaign(**campaign.model_dump())
    db.owner_id = user.id
    db.category_id = campaign.category_id
    await db.insert_with_id()

    history = History(
        campaign_id=db.campaign_id,
        action="created",
        changed_by=user.id
    )
    await history.insert_with_id()

    # Notify all users
    all_users = await User.find_all().to_list()
    for u in all_users:
        notif = Notification(
            user_id=u.id,
            campaign_id=db.campaign_id,
            message="created",
        )
        await notif.insert_with_id()

    result = db.model_dump(exclude={"id", "revision_id"})
    return {"data": result}


@router.put("/{id}", response_model=Response[dict])
async def update_campaign(
    id: int,
    campaign: CampaignUpdate,
    user: User = Depends(get_current_user)
):
    data = await Campaign.find_one(Campaign.campaign_id == id)

    if not data:
        raise HTTPException(status_code=404, detail="Campaign not found")

    if data.owner_id != user.id:
        raise HTTPException(
            status_code=403,
            detail="Only the campaign owner can update this campaign",
        )

    update_data = campaign.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        if hasattr(data, key):
            setattr(data, key, value)

    await data.save()

    history = History(
        campaign_id=data.campaign_id,
        action="updated",
        changed_by=user.id
    )
    await history.insert_with_id()

    notification = Notification(
        user_id=data.owner_id,
        campaign_id=data.campaign_id,
        message="updated"
    )
    await notification.insert_with_id()

    result = data.model_dump(exclude={"id", "revision_id"})
    return {"data": result}


@router.delete("/{id}", status_code=204)
async def delete_campaign(
    id: int,
    user: User = Depends(get_current_user)
):
    data = await Campaign.find_one(Campaign.campaign_id == id)

    if not data:
        raise HTTPException(status_code=404, detail="Campaign not found")

    if data.owner_id != user.id:
        raise HTTPException(
            status_code=403,
            detail="Only the campaign owner can delete this campaign",
        )

    deleted_campaign_id = data.campaign_id
    owner_id = data.owner_id

    # Delete related history
    await History.find(History.campaign_id == deleted_campaign_id).delete()

    # Unlink notifications from deleted campaign
    notifications = await Notification.find(
        Notification.campaign_id == deleted_campaign_id
    ).to_list()
    for n in notifications:
        n.campaign_id = None
        await n.save()

    # Delete the campaign
    await data.delete()

    # Add deletion notification
    notif = Notification(
        user_id=owner_id,
        campaign_id=None,
        message=f"deleted CMP-{deleted_campaign_id}",
    )
    await notif.insert_with_id()

    return None
