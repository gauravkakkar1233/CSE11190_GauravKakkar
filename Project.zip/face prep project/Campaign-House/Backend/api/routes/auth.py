from fastapi import APIRouter, Depends, HTTPException

from models.user import User
from schemas.user import UserCreate, UserLogin, Token, UserResponse
from core.security import hash_password, verify_password, create_access_token
from api.deps import get_current_user

router = APIRouter()

@router.post("/signup")
async def signup(user: UserCreate):
    existing = await User.find_one(User.email == user.email)

    if existing:
        raise HTTPException(status_code=400, detail="Email exists")

    db_user = User(
        email=user.email,
        hashed_password=hash_password(user.password),
        role=user.role,
        first_name=user.first_name,
        last_name=user.last_name,
        city=user.city,
        state=user.state,
        pincode=user.pincode,
    )

    await db_user.insert_with_id()

    return {"data": db_user}


@router.get("/me", response_model=UserResponse)
async def get_me(user: User = Depends(get_current_user)):
    return user


@router.post("/login", response_model=Token)
async def login(user: UserLogin):
    db_user = await User.find_one(User.email == user.email)

    if not db_user or not verify_password(user.password, db_user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = create_access_token({"sub": str(db_user.id)})

    return {
        "access_token": token,
        "token_type": "bearer"
    }