from typing import Optional
from beanie import Document
from datetime import datetime, timezone
from pydantic import Field


class Campaign(Document):
    campaign_id: Optional[int] = None  # auto-incremented integer
    name: str
    due_date: Optional[datetime] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    description: Optional[str] = None
    status: str = "active"
    owner_id: int = 0  # references User.id
    category_id: Optional[int] = None  # references Category.id
    city: Optional[str] = None
    state: Optional[str] = None
    pincode: Optional[str] = None
    origin_page_url: Optional[str] = None
    poster_image: Optional[str] = None

    class Settings:
        name = "campaigns"

    async def insert_with_id(self):
        """Insert this campaign with an auto-incremented integer campaign_id."""
        from models.counter import Counter
        if self.campaign_id is None:
            self.campaign_id = await Counter.next_id("campaign")
        return await self.insert()