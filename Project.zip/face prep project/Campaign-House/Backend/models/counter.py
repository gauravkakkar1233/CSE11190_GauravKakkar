from beanie import Document


class Counter(Document):
    """Auto-increment counter collection for generating sequential integer IDs."""
    name: str  # e.g. "user", "campaign", "category", etc.
    seq: int = 0

    class Settings:
        name = "counters"

    @classmethod
    async def next_id(cls, counter_name: str) -> int:
        """Atomically increment and return the next integer ID for the given counter."""
        counter = await cls.find_one(cls.name == counter_name)
        if counter is None:
            counter = cls(name=counter_name, seq=1)
            await counter.insert()
            return 1
        counter.seq += 1
        await counter.save()
        return counter.seq
