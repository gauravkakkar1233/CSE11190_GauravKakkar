from datetime import datetime, timezone
from typing import Optional
from beanie import Document
from pydantic import Field


class Notification(Document):
    id: Optional[int] = None  # auto-incremented integer
    user_id: int = 0  # references User.id
    campaign_id: Optional[int] = None  # references Campaign.campaign_id
    message: str
    is_read: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "notifications"

    async def insert_with_id(self):
        """Insert this notification with an auto-incremented integer ID."""
        from models.counter import Counter
        if self.id is None:
            self.id = await Counter.next_id("notification")
        return await self.insert()