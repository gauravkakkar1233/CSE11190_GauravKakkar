from typing import Optional
from beanie import Document
from datetime import datetime, timezone
from pydantic import Field


class User(Document):
    id: Optional[int] = None  # auto-incremented integer
    email: str
    hashed_password: str
    role: str = "user"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    pincode: Optional[str] = None

    class Settings:
        name = "users"

    async def insert_with_id(self):
        """Insert this user with an auto-incremented integer ID."""
        from models.counter import Counter
        if self.id is None:
            self.id = await Counter.next_id("user")
        return await self.insert()
