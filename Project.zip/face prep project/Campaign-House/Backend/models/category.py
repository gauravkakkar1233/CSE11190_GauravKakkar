from typing import Optional
from beanie import Document


class Category(Document):
    id: Optional[int] = None  # auto-incremented integer
    name: str

    class Settings:
        name = "categories"

    async def insert_with_id(self):
        """Insert this category with an auto-incremented integer ID."""
        from models.counter import Counter
        if self.id is None:
            self.id = await Counter.next_id("category")
        return await self.insert()