from datetime import datetime, timezone
from typing import Optional
from beanie import Document
from pydantic import Field


class History(Document):
    id: Optional[int] = None  # auto-incremented integer
    campaign_id: int = 0  # references Campaign.campaign_id
    action: str
    changed_by: int = 0  # references User.id
    time_stamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "history"

    async def insert_with_id(self):
        """Insert this history entry with an auto-incremented integer ID."""
        from models.counter import Counter
        if self.id is None:
            self.id = await Counter.next_id("history")
        return await self.insert()