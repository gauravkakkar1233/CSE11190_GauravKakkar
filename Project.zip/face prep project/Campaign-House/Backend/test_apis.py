import requests
import string
import random

BASE_URL = "http://127.0.0.1:8000"

PASS = "\033[92m[PASS]\033[0m"
FAIL = "\033[91m[FAIL]\033[0m"
INFO = "\033[94m[INFO]\033[0m"
SECTION = "\033[95m"
RESET = "\033[0m"

def random_string(length=8):
    return ''.join(random.choices(string.ascii_lowercase, k=length))

def check(label, response, expected_status):
    ok = response.status_code == expected_status
    status_icon = PASS if ok else FAIL
    try:
        body = response.json()
    except Exception:
        body = response.text
    print(f"  {status_icon} {label}")
    print(f"       Status: {response.status_code} (expected {expected_status})")
    if not ok:
        print(f"       Response: {body}")
    return ok, body

def section(title):
    print(f"\n{SECTION}{'='*55}")
    print(f"  {title}")
    print(f"{'='*55}{RESET}")

results = {"passed": 0, "failed": 0}

def record(ok):
    if ok:
        results["passed"] += 1
    else:
        results["failed"] += 1

def run_tests():
    email = f"test_{random_string()}@example.com"
    password = "TestPass@123"

    # ─────────────────────────────────────────────
    section("1. HEALTH CHECK")
    r = requests.get(f"{BASE_URL}/")
    ok, _ = check("GET / — root health check", r, 200)
    record(ok)

    # ─────────────────────────────────────────────
    section("2. AUTH — SIGNUP")

    signup_data = {
        "email": email,
        "password": password,
        "role": "admin",
        "first_name": "Test",
        "last_name": "User",
        "city": "Mumbai",
        "state": "Maharashtra",
        "pincode": "400001"
    }
    r = requests.post(f"{BASE_URL}/signup", json=signup_data)
    ok, body = check(f"POST /signup — new user ({email})", r, 200)
    record(ok)

    # Duplicate signup
    r2 = requests.post(f"{BASE_URL}/signup", json=signup_data)
    ok2, _ = check("POST /signup — duplicate email (expect 400)", r2, 400)
    record(ok2)

    # ─────────────────────────────────────────────
    section("3. AUTH — LOGIN")

    r = requests.post(f"{BASE_URL}/login", json={"email": email, "password": password})
    ok, body = check("POST /login — valid credentials", r, 200)
    record(ok)

    if not ok:
        print(f"\n{FAIL} Login failed — cannot continue tests that require auth.")
        print_summary()
        return

    token = body.get("access_token")
    headers = {"Authorization": f"Bearer {token}"}
    print(f"  {INFO} Token acquired.")

    # Wrong password
    r = requests.post(f"{BASE_URL}/login", json={"email": email, "password": "wrongpass"})
    ok, _ = check("POST /login — wrong password (expect 401)", r, 401)
    record(ok)

    # ─────────────────────────────────────────────
    section("4. AUTH — GET CURRENT USER")

    r = requests.get(f"{BASE_URL}/me", headers=headers)
    ok, _ = check("GET /me — authenticated", r, 200)
    record(ok)

    r = requests.get(f"{BASE_URL}/me")  # No token
    ok, _ = check("GET /me — no token (expect 401/403)", r, 403)
    record(ok)

    # ─────────────────────────────────────────────
    section("5. CAMPAIGNS — CREATE")

    camp_data = {
        "name": f"Campaign_{random_string()}",
        "description": "This is a test campaign description",
        "category_id": 1,
        "state": "Maharashtra",
        "city": "Mumbai"
    }
    r = requests.post(f"{BASE_URL}/campaigns", json=camp_data, headers=headers)
    ok, body = check("POST /campaigns — create campaign (admin)", r, 201)
    record(ok)

    campaign_id = None
    if ok:
        campaign_id = body.get("data", {}).get("campaign_id")
        print(f"  {INFO} Created campaign_id: {campaign_id}")

    # ─────────────────────────────────────────────
    section("6. CAMPAIGNS — READ")

    r = requests.get(f"{BASE_URL}/campaigns", headers=headers)
    ok, body = check("GET /campaigns — list all", r, 200)
    record(ok)
    if ok:
        count = len(body.get("data", []))
        print(f"  {INFO} Campaigns returned: {count}")

    r = requests.get(f"{BASE_URL}/campaigns?limit=2", headers=headers)
    ok, _ = check("GET /campaigns?limit=2 — pagination", r, 200)
    record(ok)

    r = requests.get(f"{BASE_URL}/campaigns?sort=latest", headers=headers)
    ok, _ = check("GET /campaigns?sort=latest", r, 200)
    record(ok)

    r = requests.get(f"{BASE_URL}/campaigns?sort=name", headers=headers)
    ok, _ = check("GET /campaigns?sort=name", r, 200)
    record(ok)

    r = requests.get(f"{BASE_URL}/campaigns?status=active", headers=headers)
    ok, _ = check("GET /campaigns?status=active — filter", r, 200)
    record(ok)

    r = requests.get(f"{BASE_URL}/campaigns?q=test", headers=headers)
    ok, _ = check("GET /campaigns?q=test — search", r, 200)
    record(ok)

    r = requests.get(f"{BASE_URL}/campaigns?state=Maharashtra", headers=headers)
    ok, _ = check("GET /campaigns?state=Maharashtra — filter by state", r, 200)
    record(ok)

    if campaign_id:
        r = requests.get(f"{BASE_URL}/campaigns/{campaign_id}", headers=headers)
        ok, _ = check(f"GET /campaigns/{campaign_id} — get by id", r, 200)
        record(ok)

        r = requests.get(f"{BASE_URL}/campaigns/99999999", headers=headers)
        ok, _ = check("GET /campaigns/99999999 — non-existent (expect 404)", r, 404)
        record(ok)

    # ─────────────────────────────────────────────
    section("7. CAMPAIGNS — STATS")

    r = requests.get(f"{BASE_URL}/campaigns/stats", headers=headers)
    ok, body = check("GET /campaigns/stats", r, 200)
    record(ok)
    if ok:
        print(f"  {INFO} Stats: total={body.get('total')}, active={body.get('active')}, completed={body.get('completed')}")

    # ─────────────────────────────────────────────
    section("8. CAMPAIGNS — UPDATE")

    if campaign_id:
        update_data = {"name": f"Updated_{random_string()}", "description": "Updated description"}
        r = requests.put(f"{BASE_URL}/campaigns/{campaign_id}", json=update_data, headers=headers)
        ok, _ = check(f"PUT /campaigns/{campaign_id} — update campaign", r, 200)
        record(ok)

        r = requests.put(f"{BASE_URL}/campaigns/99999999", json=update_data, headers=headers)
        ok, _ = check("PUT /campaigns/99999999 — non-existent (expect 404)", r, 404)
        record(ok)
    else:
        print(f"  {INFO} Skipping update tests — no campaign_id available")

    # ─────────────────────────────────────────────
    section("9. NOTIFICATIONS")

    r = requests.get(f"{BASE_URL}/notifications", headers=headers)
    ok, body = check("GET /notifications — list", r, 200)
    record(ok)

    notif_id = None
    if ok:
        notifs = body.get("data", [])
        print(f"  {INFO} Notifications count: {len(notifs)}")
        if notifs:
            notif_id = notifs[0].get("notification_id")
            print(f"  {INFO} First notification_id: {notif_id}")

    if notif_id:
        r = requests.patch(f"{BASE_URL}/notifications/{notif_id}/read", headers=headers)
        ok, _ = check(f"PATCH /notifications/{notif_id}/read — mark read", r, 200)
        record(ok)

    r = requests.post(f"{BASE_URL}/notifications/read-all", headers=headers)
    ok, body = check("POST /notifications/read-all — mark all read", r, 200)
    record(ok)
    if ok:
        print(f"  {INFO} Notifications marked read: {body.get('updated')}")

    # ─────────────────────────────────────────────
    section("10. CAMPAIGNS — DELETE (cleanup)")

    if campaign_id:
        r = requests.delete(f"{BASE_URL}/campaigns/{campaign_id}", headers=headers)
        ok, _ = check(f"DELETE /campaigns/{campaign_id} — delete campaign", r, 204)
        record(ok)

        r = requests.get(f"{BASE_URL}/campaigns/{campaign_id}", headers=headers)
        ok, _ = check(f"GET /campaigns/{campaign_id} — confirm deleted (expect 404)", r, 404)
        record(ok)
    else:
        print(f"  {INFO} Skipping delete test — no campaign_id available")

    # ─────────────────────────────────────────────
    print_summary()


def print_summary():
    total = results["passed"] + results["failed"]
    print(f"\n{SECTION}{'='*55}")
    print(f"  TEST SUMMARY")
    print(f"{'='*55}{RESET}")
    print(f"  Total : {total}")
    print(f"  {PASS} Passed: {results['passed']}")
    if results["failed"]:
        print(f"  {FAIL} Failed: {results['failed']}")
    else:
        print(f"  \033[92mAll tests passed! 🎉\033[0m")
    print()


if __name__ == "__main__":
    run_tests()
