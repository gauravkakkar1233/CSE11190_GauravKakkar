from motor.motor_asyncio import AsyncIOMotorClient
from beanie import init_beanie
from core.config import settings

client: AsyncIOMotorClient = None


async def init_db():
    """Initialize Motor client and Beanie ODM with all document models."""
    global client

    # Import document models
    from models.user import User
    from models.campaign import Campaign
    from models.category import Category
    from models.notification import Notification
    from models.history import History
    from models.counter import Counter

    client = AsyncIOMotorClient(settings.MONGODB_URL)
    db = client[settings.MONGODB_DB_NAME]

    await init_beanie(
        database=db,
        document_models=[User, Campaign, Category, Notification, History, Counter],
    )


async def close_db():
    """Close the Motor client connection."""
    global client
    if client:
        client.close()
