"""
Migrate data from the old SQLite database.db into MongoDB.

Usage:
    python migrate_to_mongo.py

Requires MongoDB to be running and MONGODB_URL / MONGODB_DB_NAME
to be set in .env (or defaults to localhost:27017 / campaign_house).
"""
import os
import sys
import asyncio
import sqlite3
from datetime import datetime

# Ensure the Backend directory is on the path
sys.path.insert(0, os.path.dirname(__file__))

DB_FILE = "database.db"
BACKUP_FILE = "database_old.db"


async def migrate():
    from db.database import init_db, close_db
    from models.user import User
    from models.campaign import Campaign
    from models.counter import Counter

    # --- Read old SQLite data -----------------------------------------------------------
    source = DB_FILE if os.path.exists(DB_FILE) else BACKUP_FILE
    if not os.path.exists(source):
        print(f"No {DB_FILE} or {BACKUP_FILE} found to migrate.")
        return

    print(f"Reading from {source} ...")
    conn = sqlite3.connect(source)
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT id, email, hashed_password, created_at FROM user")
        users = cursor.fetchall()
    except Exception as e:
        print("Failed to read users:", e)
        users = []

    try:
        cursor.execute(
            "SELECT campaign_id, name, due_date, created_at, "
            "description, status, owner_id, category_id, "
            "city, state, pincode, origin_page_url, poster_image "
            "FROM campaign"
        )
        campaigns = cursor.fetchall()
    except Exception as e:
        print("Failed to read campaigns:", e)
        campaigns = []

    conn.close()
    print(f"Read {len(users)} users and {len(campaigns)} campaigns from SQLite.")

    # --- Write into MongoDB -------------------------------------------------------------
    await init_db()

    max_user_id = 0
    for u in users:
        uid, email, hashed_pw, created_at_str = u
        created_at_dt = datetime.fromisoformat(created_at_str) if created_at_str else datetime.now()
        db_user = User(
            id=uid,
            email=email,
            hashed_password=hashed_pw,
            role="admin",
            created_at=created_at_dt,
            first_name="Migrated",
            last_name="User",
            city="Local",
            state="State",
            pincode="123456",
        )
        await db_user.insert()
        max_user_id = max(max_user_id, uid)

    max_campaign_id = 0
    for c in campaigns:
        cid = c[0]
        due_date_dt = datetime.fromisoformat(c[2]) if c[2] else None
        created_at_dt = datetime.fromisoformat(c[3]) if c[3] else datetime.now()
        owner_id = c[6] if c[6] else (users[0][0] if users else 1)

        db_campaign = Campaign(
            campaign_id=cid,
            name=c[1],
            due_date=due_date_dt,
            created_at=created_at_dt,
            description=c[4] or f"Description for {c[1]}",
            status=c[5] or "active",
            owner_id=owner_id,
            category_id=c[7],
            city=c[8] or "Local",
            state=c[9] or "State",
            pincode=c[10] or "123456",
            origin_page_url=c[11],
            poster_image=c[12],
        )
        await db_campaign.insert()
        max_campaign_id = max(max_campaign_id, cid)

    # Set counters so future inserts continue from after the migrated IDs
    if max_user_id:
        counter = await Counter.find_one(Counter.name == "user")
        if counter:
            counter.seq = max_user_id
            await counter.save()
        else:
            await Counter(name="user", seq=max_user_id).insert()

    if max_campaign_id:
        counter = await Counter.find_one(Counter.name == "campaign")
        if counter:
            counter.seq = max_campaign_id
            await counter.save()
        else:
            await Counter(name="campaign", seq=max_campaign_id).insert()

    await close_db()
    print("Migration completed successfully!")


if __name__ == "__main__":
    asyncio.run(migrate())
