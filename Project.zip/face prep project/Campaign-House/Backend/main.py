from fastapi import FastAPI
from contextlib import asynccontextmanager
from fastapi.middleware.cors import CORSMiddleware
from db.database import init_db, close_db
from api.routes import campaign, auth, notification


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield
    await close_db()


app = FastAPI(lifespan=lifespan)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(campaign.router, prefix="/campaigns", tags=["Campaigns"])
app.include_router(auth.router, tags=["Auth"])
app.include_router(notification.router, prefix="/notifications", tags=["Notifications"])


@app.get("/")
async def root():
    return {"message": "Hello World"}