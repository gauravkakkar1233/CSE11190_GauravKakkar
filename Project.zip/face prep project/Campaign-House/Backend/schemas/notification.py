from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class NotificationRead(BaseModel):
    id: int
    user_id: int
    campaign_id: Optional[int] = None
    message: str
    is_read: bool
    created_at: datetime
