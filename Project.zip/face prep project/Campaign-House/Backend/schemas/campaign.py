from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class CampaignCreate(BaseModel):
    name: str
    due_date: Optional[datetime] = None
    description: Optional[str] = None
    status: Optional[str] = "active"
    category_id: Optional[int] = None
    city: Optional[str] = None
    state: Optional[str] = None
    pincode: Optional[str] = None
    origin_page_url: Optional[str] = None
    poster_image: Optional[str] = None

class CampaignUpdate(BaseModel):
    name: Optional[str] = None
    due_date: Optional[datetime] = None
    description: Optional[str] = None
    category_id: Optional[int] = None
    origin_page_url: Optional[str] = None
    state: Optional[str] = None
    pincode: Optional[str] = None
    poster_image: Optional[str] = None

class CampaignRead(BaseModel):
    campaign_id: int
    name: str
    description: Optional[str] = None
    status: str
    due_date: Optional[datetime] = None
    created_at: datetime
    owner_id: int
    city: Optional[str] = None
    state: Optional[str] = None
    pincode: Optional[str] = None
    category_id: Optional[int] = None
    origin_page_url: Optional[str] = None
    poster_image: Optional[str] = None