from datetime import datetime
from pydantic import BaseModel


class HistoryRead(BaseModel):
    id: int
    campaign_id: int
    action: str
    changed_by: int
    time_stamp: datetime