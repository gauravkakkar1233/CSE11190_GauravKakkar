import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    PROJECT_NAME: str = "Campaign House API"

    MONGODB_URL: str = os.getenv("ATLASDB_URL", "mongodb://localhost:27017")
    # Extract DB name from the Atlas URL path, or default to "campaign_house"
    MONGODB_DB_NAME: str = "campaign_house"

    SECRET_KEY: str = os.getenv("SECRET", "supersecretkey")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60

    # Cloudinary settings
    CLOUD_NAME: str = os.getenv("CLOUD_NAME", "")
    CLOUD_API_KEY: str = os.getenv("CLOUD_API_KEY", "")
    CLOUD_API_SECRET: str = os.getenv("CLOUD_API_SECRET", "")

    def __init__(self) -> None:
        if not self.MONGODB_URL:
            raise RuntimeError(
                "ATLASDB_URL is not set. Define it in Backend/.env "
                "(e.g. mongodb+srv://user:pass@cluster.mongodb.net/dbname)."
            )


settings = Settings()
